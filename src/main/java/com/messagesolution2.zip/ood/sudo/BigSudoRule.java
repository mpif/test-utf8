package com.messagesolution2.ood.sudo;

public class BigSudoRule {

}
