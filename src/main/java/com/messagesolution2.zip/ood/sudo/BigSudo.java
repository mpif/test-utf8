package com.messagesolution2.ood.sudo;

import java.util.List;

public class BigSudo {

//	private List<SmallSudo> datas = new ArrayList<SmallSudo>();
	private List<SmallSudo> datas;
	private List<BigSudoColumn> columns;
	private List<BigSudoRow> rows;
	private Integer[][] originDatas;
	
	public void initOriginDatas() {
		
	}
	
	public void handleOriginDatas() {
		
	}
	
	public boolean checkRule() {
		boolean match = false;
		
		return match;
	}
	
}
