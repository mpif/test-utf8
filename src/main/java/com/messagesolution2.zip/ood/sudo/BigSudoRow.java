package com.messagesolution2.ood.sudo;

import java.util.ArrayList;
import java.util.List;

public class BigSudoRow {

//	List<Integer> datas = new ArrayList<Integer>();
	private List<Integer> datas;
	private BigSudoColumnRowRule bigSudoColumnRowRule;
}
