package com.messagesolution2.socket;

public class QueuedReader {

}
