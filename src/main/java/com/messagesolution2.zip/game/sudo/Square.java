package com.messagesolution2.game.sudo;

public class Square {

	SmallSquare[][] smallSquares = new SmallSquare[3][3];

	public SmallSquare[][] getSmallSquares() {
		return smallSquares;
	}

	public void setSmallSquares(SmallSquare[][] smallSquares) {
		this.smallSquares = smallSquares;
	}

}
