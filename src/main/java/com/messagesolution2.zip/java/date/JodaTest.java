package com.messagesolution2.java.date;

public class JodaTest {

	/**
	 * @param args
	 */
	public static void main(String[] args) {

	}

}
