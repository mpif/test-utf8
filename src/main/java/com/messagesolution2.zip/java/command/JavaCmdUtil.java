package com.messagesolution2.java.command;

public class JavaCmdUtil {

	/**
	 * @param args
	 */
	public static void main(String[] args) {

	}

}
