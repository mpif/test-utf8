package com.messagesolution2.java.thread.concurrent;

public class ResultSet {

	private String name;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

}
