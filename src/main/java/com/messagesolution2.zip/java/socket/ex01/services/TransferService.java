package com.messagesolution2.java.socket.ex01.services;

/*
 * @Author: Sean
 * @Time: 2015-05-15 11:23:34
 */
public interface TransferService {

	public String transfer(String username);

}
