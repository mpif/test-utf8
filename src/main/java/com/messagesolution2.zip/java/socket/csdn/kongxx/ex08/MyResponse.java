package com.messagesolution2.java.socket.csdn.kongxx.ex08;

/*
 * @Author: Sean
 * @Time: 2015-05-18 14:53:40
 */

import java.io.Serializable;

public interface MyResponse extends Serializable {

	Object getResult();
}
