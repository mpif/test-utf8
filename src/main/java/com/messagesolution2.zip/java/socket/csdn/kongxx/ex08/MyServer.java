package com.messagesolution2.java.socket.csdn.kongxx.ex08;

/*
 * @Author: Sean
 * @Time: 2015-05-18 14:50:36
 */

public interface MyServer {

	public void startup() throws Exception;

	public void shutdown() throws Exception;
}
