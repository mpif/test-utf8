package com.messagesolution2.java.service;

public class QueuedReader {

}
