package com.messagesolution2.java.classes;

public class MyCompanyDomain {

	protected String domain;

	public String getDomain() {
		return domain;
	}

	public void setDomain(String domain) {
		this.domain = domain;
	}

}
