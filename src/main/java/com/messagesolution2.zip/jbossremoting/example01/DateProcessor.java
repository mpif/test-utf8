package com.messagesolution2.jbossremoting.example01;

import java.util.Date;

public interface DateProcessor {
	public String formatDate(Date dateToConvert);
}
