/**
 * 
 */
package com.messagesolution2.jbossremoting.test;

/**
 * @author luping
 *
 */
public class KeyNotFoundExcepton extends Exception {

	public KeyNotFoundExcepton(String message) {
		super(message);
	}

	public KeyNotFoundExcepton(Throwable e) {
		super(e);
	}

	/**
	 * 
	 */
	private static final long serialVersionUID = -5678642723273191100L;

}
