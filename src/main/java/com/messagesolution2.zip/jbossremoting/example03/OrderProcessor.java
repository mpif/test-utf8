package com.messagesolution2.jbossremoting.example03;

public interface OrderProcessor {
	public Order processOrder(Order order);
}
