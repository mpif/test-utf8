#Metadata Info, DO NOT MIDOFY.
#Thu Dec 18 18:43:52 CST 2014
stream.1.signature=a12fe63d3a5fdacb5fae3ce3458c4f50
stream.3.size=3712
streams.elapse=1
streams.uidkey=141889943211520000
streams.count=3
stream.1.size=924
stream.3.signature=7e93d0187a305ebf5bcd0b337d7d37ac
stream.2.signature=1aad6beaab646a4ad5f6b855f4ba9985
streams.size=7620
streams.catalog=email_body_20140803
stream.2.size=2984
