package com.messagesolution2.apache.commons.io;

import org.apache.commons.io.FileUtils;

public class FileUtilsTest {

	public static void main(String[] args) {
		System.out.println(FileUtils.ONE_KB);
		System.out.println(FileUtils.ONE_MB);
		System.out.println(FileUtils.ONE_GB);
	}

}
