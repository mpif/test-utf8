package com.messagesolution2.javaaccesspermission.packagepermission;

public class PackagePermission {

	String date;
	protected int time;

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}
}
