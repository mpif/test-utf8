package com.messagesolution2.javaaccesspermission;

public class ChildClass extends BaseClass {

	private int id;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getSuperName() {
		return name;
	}
}
