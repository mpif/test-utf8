package com.messagesolution2.javaaccesspermission;

import com.messagesolution2.javaaccesspermission.packagepermission.PackagePermission;

public class PackagePermissionChild extends PackagePermission {

}
