package com.messagesolution2.designpattern.factory.factorymethod;

public interface IFactory {
	public ICar createCar();
}
