package com.messagesolution2.designpattern.factory.factorymethod;

public class Engine {
	public void getStyle() {
		System.out.println("这是汽车的发动机");
	}
}
