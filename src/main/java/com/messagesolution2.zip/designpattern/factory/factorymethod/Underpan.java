package com.messagesolution2.designpattern.factory.factorymethod;

public class Underpan {
	public void getStyle() {
		System.out.println("这是汽车的底盘");
	}
}
