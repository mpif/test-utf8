package com.messagesolution2.designpattern.factory.factorymethod;

public class Wheel {
	public void getStyle() {
		System.out.println("这是汽车的轮胎");
	}
}
