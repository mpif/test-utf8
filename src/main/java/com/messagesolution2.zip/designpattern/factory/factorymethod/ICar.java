package com.messagesolution2.designpattern.factory.factorymethod;

public interface ICar {
	public void show();
}
