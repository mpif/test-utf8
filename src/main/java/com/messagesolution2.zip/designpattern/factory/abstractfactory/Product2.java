package com.messagesolution2.designpattern.factory.abstractfactory;

public class Product2 implements IProduct2 {
	public void show() {
		System.out.println("这是2型产品");
	}
}
