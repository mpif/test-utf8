package com.messagesolution2.designpattern.factory.abstractfactory;

public interface IProduct1 {
	public void show();
}
