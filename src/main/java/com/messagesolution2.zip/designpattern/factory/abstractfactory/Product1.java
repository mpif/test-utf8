package com.messagesolution2.designpattern.factory.abstractfactory;

public class Product1 implements IProduct1 {
	public void show() {
		System.out.println("这是1型产品");
	}
}
