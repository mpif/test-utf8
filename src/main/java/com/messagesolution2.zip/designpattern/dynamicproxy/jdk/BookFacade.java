package com.messagesolution2.designpattern.dynamicproxy.jdk;

public interface BookFacade {
	public void addBook();
}
