package com.messagesolution2.designpattern.dynamicproxy.jdk;

public class BookFacadeImpl implements BookFacade {

	@Override
	public void addBook() {
		System.out.println("增加图书方法。。。");
	}

}
