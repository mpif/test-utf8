package com.messagesolution2.designpattern.dynamicproxy.cglib;

public interface BookFacade {
	public void addBook();
}
