package com.messagesolution2.thread.filewrite;

public class MainTest {

	/**
	 * @param args
	 */
	public static void main(String[] args) {

	}

}
