package com.messagesolution2.test.dynamicproxy;

public class Bicycle implements Transport {

	public void run() throws Exception {
		System.out.println("Bicycle running!!!");
	}

}
