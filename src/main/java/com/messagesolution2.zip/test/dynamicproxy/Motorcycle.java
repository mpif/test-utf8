package com.messagesolution2.test.dynamicproxy;

public class Motorcycle implements Transport {

	public void run() throws Exception {
		System.out.println("motorcycle running !!");
	}

}
