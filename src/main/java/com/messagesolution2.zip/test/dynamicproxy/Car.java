package com.messagesolution2.test.dynamicproxy;

public class Car implements Transport {

	@Override
	public void run() throws Exception {
		System.out.println("Car running!");
	}

}
