package com.messagesolution2.test.dynamicproxy;

public interface Transport {
	public void run() throws Exception;
}
